支撑材料说明

本压缩包与论文 PDF 分开提交，包内不含承诺书、编号页、队名或校名。

环境
- Python 3
- numpy
- requests（连接官方模拟器时需要）

入口
- 问题一：q1/solver.py
- 问题二：q2/geometry.py；数字核验 q2/derive_check.py
- 问题三：python q3/run_q3.py
  依赖同目录 api.py、tactics.py、local_world.py，以及 q1/solver.py、q2/geometry.py
  连接官方模拟器前请设置环境变量 ROBOT_ID 为赛方分配的队号
- 问题四：python q4/run_q4.py
  依赖 policy.py、ledger2.py、skeleton_final.npy / .json，以及 q2/geometry.py、robot.py
  同样使用环境变量 ROBOT_ID（源码中的 YOUR_TEAM_ID 仅为占位）

说明
- 问题三默认关闭 --adaptive-step，与论文口径一致
- 问题四证书骨架为 26 点（ring 400/6 + 1300/8 + 1900/12）
- 插图为论文使用的 PNG 源文件
- AI工具使用详情.pdf 为竞赛要求的人工智能使用说明
